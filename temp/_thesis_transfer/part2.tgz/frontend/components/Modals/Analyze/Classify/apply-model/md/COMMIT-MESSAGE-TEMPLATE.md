# COMMIT-MESSAGE-TEMPLATE.md — Template Pesan Commit

**Gunakan file ini sebagai template untuk menulis pesan commit setelah verifikasi selesai.**

Instruksi:
1. Baca laporan di `VERIFY-RESULT.md`
2. Tulis pesan commit dengan format di bawah, isi field `[...]`
3. Copy-paste ke `git commit -m "..."`

---

## FORMAT COMMIT MESSAGE

```
feat: Add Apply Model menu to Classify modal

Implements complete Apply Model workflow per AGENTS.md & PLAN.md.

## Summary
- Menu baru Apply Model di Analyze → Classify (setelah Naive Bayes)
- Load model dari 3 sumber: file upload, NB result store, katalog builtin (empty)
- Validasi model schema 1.0/1.1 dengan 15 kode error terstruktur
- Auto + manual feature mapping dengan blocking peran/measure
- Scoring Naive Bayes di Rust/WASM (konsisten dengan NB prediction)
- Output 4 kolom prediksi (value, probability, per-class) + customizable names
- Output Viewer: Model Summary, Case Processing, Prediction Distribution, Confusion Matrix + metrics

## Product Decisions Met
✅ K1 — Three model sources (file, result store, builtin catalog)
✅ K2 — NB export upgraded to schema 1.1 (class_counts, class_totals)
✅ K3 — Dedicated Rust crate + WASM worker (independent from NB)
✅ K4 — Auto-match by name (exact + case-insensitive) + manual override with role/measure blocking
✅ K5 — All-missing predictor rows skip scoring, count in summary
✅ K6 — Output columns: predicted (NUMERIC/STRING auto), max prob (optional, default ON), per-class prob (optional, default OFF), names editable
✅ K7 — Output Viewer: model summary + case processing + prediction distribution + confusion matrix (if actual target mapped)
✅ K8 — Strict 2-layer validation (TS + Rust) with unified error codes (AM_E_*)
✅ K9 — Active dataset, all rows, only mapped predictors
✅ K10 — UI placement Analyze → Classify; sidebar 40%; IndexedDB key "ApplyModel"; EN labels, ID messages
✅ K11 — NB export updated, Apply Model will NOT edit NB/AGENTS.md further

## Design Principles Met
✅ P1 — Contract = NB JSON export schema (no custom model format)
✅ P2 — Multi-algorithm via parallel registries (TS adapter + Rust scorer trait)
✅ P3 — 2-layer validation with unified error codes (AM_E_*, AM_W_*)
✅ P4 — Scoring formula identical to NB (probability, smoothing, category normalization, tie-break)
✅ P5 — Computation in Rust, orchestration & I/O store in TS
✅ P6 — Standalone Rust crate (copy utilities from NB with source attribution)
✅ P7 — NB/KNN read-only (import only explicitly listed modules)

## Test Coverage
✅ Fixture D1 (model v1.1, 6 features) → 5 of 6 rows scored correctly
✅ Fixture D2 (model v1.0 legacy) → parsed & warned (AM_W_LEGACY_SCHEMA)
✅ Dataset D3 test vs expected T1–T6 (probabilities match ±0.0001)
✅ All 15 error codes tested (invalid JSON, unsupported schema, missing fields, type mismatch, etc.)
✅ Jest: apply-model/* 100% pass
✅ TS: npx tsc --noEmit -p . zero errors
✅ Rust: cargo test (apply-model) 100% pass
✅ Regression: NB tests unchanged

## Files Changed

### New Files
- frontend/components/Modals/Analyze/Classify/apply-model/
  - types/
    - model-schema.ts (ExportedModel schema 1.0/1.1, Feature, Target types)
    - apply-model.ts (SourceKind, ApplyModelForm, ApplyModelState, FeatureMapping, OutputColumnConfig)
    - apply-model-worker.ts (Worker message types)
  - adapters/
    - types.ts (ClassifierModelAdapter interface)
    - naive-bayes-adapter.ts (NB adapter: validate, descriptor, defaultOutputPrefix)
    - registry.ts (getAdapterForModelType, validateAnyModel)
  - constants/
    - apply-model-codes.ts (AM_E_*, AM_W_* codes + APPLY_MODEL_MESSAGES)
    - apply-model-default.ts (ApplyModelDefault: SourceKind, OutputColumnConfig, etc.)
    - builtin-models.ts (BUILTIN_MODELS = [] for future population)
  - hooks/
    - useApplyModelMappingRules.ts (autoMapFeatures, validateMapping, eligibility helpers)
    - useApplyModelForm.ts (Form state management via IndexedDB)
    - useApplyModelWorker.ts (Worker lifecycle & scoring orchestration)
  - services/
    - apply-model-service.ts (Entry point: loadModel, validate, score, writeOutputColumns)
    - apply-model-analysis.ts (Scoring orchestration + summary computation)
    - apply-model-output-formatter.ts (Output Viewer data: ModelSummary, CaseProcessing, PredictionDistribution, ConfusionMatrix, metrics)
    - __fixtures__/
      - nb-model-v1_1.json (D1: test fixture with class_counts & class_totals)
      - nb-model-v1_0.json (D2: legacy fixture without new fields)
  - dialogs/
    - ApplyModelDialog.tsx (Main modal component)
    - LoadModelTab.tsx (Load & validate model)
    - MapFeaturesTab.tsx (Auto + manual feature mapping)
    - ScoreDatasetTab.tsx (Scoring & progress)
    - OutputViewerTab.tsx (Summary + stats + confusion matrix)
  - rust/
    - Cargo.toml (wasm-pack configuration, dependencies)
    - src/
      - lib.rs (WASM exports)
      - model_loader.rs (Parse & validate model JSON)
      - scoring/
        - naive_bayes_scorer.rs (NB probability computation)
        - classifier_scorer.rs (Trait ClassifierScorer + registry)
      - tests/ (Test fixtures D1, D2, D3 with expected T1–T6)
  - __tests__/
    - adapters/naive-bayes-adapter.test.ts (Validate all 15 error codes)
    - adapters/registry.test.ts (getAdapterForModelType, validateAnyModel)
    - hooks/useApplyModelMappingRules.test.ts (Auto-match, validation, eligibility)
    - services/apply-model-service.test.ts (Integration: load → validate → score → format output)
    - services/apply-model-output-formatter.test.ts (Confusion matrix, metrics, kappa)

- frontend/public/workers/Classify/ApplyModel/
  - apply-model.worker.js (Worker entry point)
  - pkg/ (WASM compiled from rust/)

### Modified Files
- frontend/components/Modals/Analyze/Classify/index.tsx
  - Register Apply Model menu after Naive Bayes
  - Add MenubarSeparator between NB and Apply Model

- frontend/components/Modals/Analyze/Classify/naive-bayes/
  - rust/src/stats/save.rs
    - Add `class_counts: Vec<u64>` to ExportTarget
    - Add `class_totals: HashMap<String, u64>` to ExportFeature::Categorical
    - Update schema_version to "1.1"
  - services/naive-bayes-analysis-formatter.ts
    - Update NaiveBayesTrainedModelRaw type to include optional class_counts
  - services/naive-bayes-analysis.ts
    - Bump NAIVE_BAYES_ANALYSIS_VERSION
  - rust/Cargo.lock (rebuild)

- frontend/public/workers/Classify/NaiveBayes/
  - apply-model.worker.js
    - Bump NAIVE_BAYES_WASM_VERSION & query string ?v=
  - pkg/ (rebuilt WASM for schema 1.1)

## Verification Report
Laporan lengkap di `VERIFY-RESULT.md` (folder apply-model):
- 17 fase plan terpenuhi: [✅ / ⚠️ / ❌]
- Kontrak K1–K11 terpenuhi: [✅ / ⚠️ / ❌]
- Prinsip P1–P7 terpenuhi: [✅ / ⚠️ / ❌]
- Error code coverage: [15/15]
- Test pass rate: [akan diisi dari VERIFY-RESULT.md]

## Known Issues / Notes
[Dari VERIFY-RESULT.md BAGIAN F akan diisi di sini jika ada]

Contoh jika ada warning:
```
⚠️ Note: Output Viewer confusion matrix calculation assumes no missing actual target values.
         Edge case handling documented in apply-model-output-formatter.ts:computeConfusionMatrix().
```

## Closes
- Implementasi lengkap Apply Model per AGENTS.md product spec
- Siap untuk user testing di Statify UI
- Next task: populate builtin-models catalog (separate PR)

Co-Authored-By: Claude Opus <noreply@anthropic.com>
Claude-Session: [session_url_dari_VERIFY-RESULT.md]
```

---

## INSTRUKSI PENGISIAN

1. **Baca VERIFY-RESULT.md** sepenuhnya
2. **Isi field berikut:**
   - `[✅ / ⚠️ / ❌]` → dari kesimpulan BAGIAN F
   - `[akan diisi dari VERIFY-RESULT.md]` → dari BAGIAN D (test results)
   - `[Dari VERIFY-RESULT.md BAGIAN F akan diisi di sini jika ada]` → dari issue/notes
   - `[session_url_dari_VERIFY-RESULT.md]` → URL session Claude yang melakukan verifikasi

3. **Copy seluruh block pesan** (dari `feat:` hingga `Claude-Session:`)
4. **Jalankan git commit:**
   ```bash
   cd frontend/components/Modals/Analyze/Classify/apply-model
   git commit -m "$(cat <<'MSGEOF'
   [paste pesan dari sini]
   MSGEOF
   )"
   ```

---

## CATATAN PENTING

- **Jangan hardcode issue tracker IDs** (mis. "Closes #123") jika belum ada task/issue di repo
- **Session URL** untuk co-authored-by bisa dilihat di browser address bar (`claude.ai/code/session_...`)
- **Durasi verifikasi** bisa di-track dari tanggal di VERIFY-RESULT.md
- **Jika ada blocker dari verifikasi**, jangan commit sampai selesai diperbaiki (hapus atau update field blockers)

---

**Template ini siap pakai. Update setelah VERIFY-RESULT.md selesai diisi.**

