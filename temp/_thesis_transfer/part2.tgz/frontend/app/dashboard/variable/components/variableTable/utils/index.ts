export { transformVariablesToTableData } from './utils';
