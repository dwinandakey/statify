export { FactorAnalysisGuide } from './FactorAnalysisGuide';
