"""Pembanding scikit-learn untuk evaluasi akurasi numerik Statify (Modul Text Analytics).
Protokol: split stratified 70/30 seed 42 dibuat SEKALI di sini dan disimpan sebagai train.csv/test.csv.
Di Statify: latih NB pada train.csv (Raw Text = 'Text Tweet', Target = 'Sentiment'), Export Model,
lalu Apply Model pada test.csv dengan Actual target = 'Sentiment'. Bandingkan dengan angka di bawah.
Vectorizer meniru preset Statify (STWV/DOKUMENTASI.md B.2–B.4)."""
import re, json, sys, math
import numpy as np, pandas as pd
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB, BernoulliNB, ComplementNB
from sklearn.metrics import accuracy_score, cohen_kappa_score, confusion_matrix, precision_recall_fscore_support
import sklearn
SRC = sys.argv[1]
df = pd.read_csv(SRC, encoding='utf-8-sig')
tr, te = train_test_split(df, test_size=0.30, stratify=df['Sentiment'], random_state=42)
tr = tr.sort_values('Id'); te = te.sort_values('Id')
tr.to_csv('pilkada_train.csv', index=False); te.to_csv('pilkada_test.csv', index=False)
DELIM = re.compile(r"[\s.,;:'\"()?!]+")
def tokens(doc, lowercase=True):
    s = doc.lower() if lowercase else doc
    return [t for t in DELIM.split(s) if t]
def build_vocab(docs, keep=1000, minfreq=1):
    tot = Counter(); 
    for d in docs: tot.update(tokens(d))
    items = [(w,c) for w,c in tot.items() if c >= minfreq]
    if keep and len(items) > keep:
        items.sort(key=lambda wc: (-wc[1], wc[0].encode('utf-8')))
        items = items[:keep]
    return sorted([w for w,_ in items], key=lambda w: w.encode('utf-8'))
def counts(docs, vocab):
    idx = {w:i for i,w in enumerate(vocab)}
    X = np.zeros((len(docs), len(vocab)))
    for r,d in enumerate(docs):
        for t in tokens(d):
            j = idx.get(t)
            if j is not None: X[r,j] += 1
    return X
def sk_preset(Xtr, Xte):
    # raw TF, smooth IDF (fit on train), L2
    n = Xtr.shape[0]; dfreq = (Xtr > 0).sum(0)
    idf = np.log((1+n)/(1+dfreq)) + 1
    def tr_(X):
        V = X*idf; nr = np.linalg.norm(V, axis=1, keepdims=True); nr[nr==0]=1; return V/nr
    return tr_(Xtr), tr_(Xte)
vocab = build_vocab(tr['Text Tweet'].astype(str))
Xtr = counts(tr['Text Tweet'].astype(str), vocab); Xte = counts(te['Text Tweet'].astype(str), vocab)
ytr = tr['Sentiment'].values; yte = te['Sentiment'].values
configs = {
 'K1 Weka default + Multinomial': (MultinomialNB(alpha=1.0), Xtr, Xte),
 'K2 Weka default + Bernoulli': (BernoulliNB(alpha=1.0, binarize=0.0), Xtr, Xte),
 'K3 Weka default + Complement': (ComplementNB(alpha=1.0, norm=False), Xtr, Xte),
}
a,b = sk_preset(Xtr, Xte)
configs['K4 scikit-learn (Count/Smooth/L2) + Multinomial'] = (MultinomialNB(alpha=1.0), a, b)
out = {'sklearn': sklearn.__version__, 'n_train': len(tr), 'n_test': len(te), 'vocab_size': len(vocab),
       'train_class': dict(Counter(ytr)), 'test_class': dict(Counter(yte)), 'configs': {}}
for name,(m,A,B) in configs.items():
    m.fit(A, ytr); p = m.predict(B); pr = m.predict_proba(B)
    P,R,F,S = precision_recall_fscore_support(yte, p, labels=m.classes_, zero_division=0)
    cm = confusion_matrix(yte, p, labels=m.classes_)
    out['configs'][name] = {'accuracy': round(accuracy_score(yte,p),6), 'kappa': round(cohen_kappa_score(yte,p),6),
        'precision': dict(zip(m.classes_, np.round(P,6))), 'recall': dict(zip(m.classes_, np.round(R,6))),
        'f1': dict(zip(m.classes_, np.round(F,6))), 'macro_f1': round(F.mean(),6),
        'confusion(actual x pred)': cm.tolist(), 'classes': list(m.classes_),
        'mean_p_positive_test': round(pr[:, list(m.classes_).index('positive')].mean(),6)}
    pd.DataFrame({'Id': te['Id'].values, 'actual': yte, 'pred': p, 'p_positive': pr[:, list(m.classes_).index('positive')]}).to_csv(f"pred_{name.split()[0]}.csv", index=False)
json.dump(out, open('sklearn_results.json','w'), indent=1, default=lambda o: float(o) if isinstance(o,(np.floating,)) else int(o))
print(json.dumps(out, indent=1, default=lambda o: float(o) if isinstance(o,(np.floating,)) else int(o)))
